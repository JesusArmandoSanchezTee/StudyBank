package com.example.studybank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
